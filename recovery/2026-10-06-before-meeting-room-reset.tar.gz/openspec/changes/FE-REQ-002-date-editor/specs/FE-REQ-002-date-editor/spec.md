# FE-REQ-002-date-editor · Date editor and overdue cues

## Purpose

Define the date editor and overdue cues responsibilities owned by Frontend for REQ-002, due dates & overdue cues.

## ADDED Requirements

### Requirement: Accessible date editing
The UI SHALL provide each task with an accessibly named date field and explicit clear control. Saving SHALL submit a YYYY-MM-DD string, clearing SHALL submit null, and a successful response SHALL determine the displayed value. A failed update SHALL preserve the existing displayed date and announce an error.

#### Scenario: Keyboard date save
- **WHEN** a keyboard user enters a valid date and saves it
- **THEN** the UI submits the YYYY-MM-DD value and displays the date returned by the successful response

#### Scenario: Explicit clear
- **WHEN** a keyboard user activates the clear control for a dated task
- **THEN** the UI submits null and removes the displayed date after a successful response

#### Scenario: Failed date update
- **WHEN** saving or clearing a due date fails
- **THEN** the UI retains the previously displayed date and announces an error

### Requirement: Local-date overdue cues
The UI SHALL keep a task's due date visible and show an overdue text label only for an incomplete task whose due date precedes the viewer's local calendar date. The comparison SHALL preserve date-only values without timezone conversion.

#### Scenario: Due today
- **WHEN** an incomplete task is due on the viewer's local calendar date
- **THEN** its due date remains visible without an overdue cue

#### Scenario: Overdue task
- **WHEN** an incomplete task is due before the viewer's local calendar date
- **THEN** its due date remains visible with an overdue text label

#### Scenario: Completed task
- **WHEN** a completed task has a due date before the viewer's local calendar date
- **THEN** its due date remains visible without an overdue cue
