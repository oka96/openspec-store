# Design

## Context

See proposal.md for motivation and the Frontend delta spec for observable
behavior. The implementing workspace uses plain browser JavaScript with an
in-memory task API. The API contract accepts YYYY-MM-DD strings, uses null for an
explicit clear, preserves omitted fields, and returns date-only strings unchanged.

## Goals / Non-Goals

**Goals:** Provide keyboard-accessible date editing, keep committed UI state in
sync with successful API responses, and calculate overdue cues against the
viewer's local calendar date without converting date-only values to timestamps.

**Non-Goals:** Client-side ownership of authoritative calendar validation,
time-of-day reminders, recurring schedules, calendar integration, and
notification delivery.

## Decisions

1. Use a native date input with an associated accessible name and a separately
   named clear button. Native date controls provide keyboard behavior and
   date-oriented semantics without adding a custom parser; a free-form text field
   was rejected because it would duplicate validation and accessibility work.

2. Save a selected value as `{ dueDate: "YYYY-MM-DD" }` and clear with
   `{ dueDate: null }`; the Frontend does not omit `dueDate` for either action.
   Update the committed display from the successful response. On failure, retain
   the prior committed value and expose an announced error. Optimistic replacement
   was rejected because a rejected date could appear saved.

3. Build today's YYYY-MM-DD value from the browser's local year, month, and day,
   then compare it with the returned date string. Do not parse `YYYY-MM-DD` with a
   UTC-based timestamp constructor. Direct local date-component comparison avoids
   timezone shifts; timestamp comparison was rejected because it can move the
   calendar boundary for some viewers.

4. Render the date for dated tasks regardless of completion state. Add visible
   overdue text only when the task is incomplete and its date sorts before the
   local today value; due-today and completed tasks suppress the cue.

## Risks / Trade-offs

- [Client clock changes while the page stays open] → Recompute overdue state on
  each task-list render and whenever tasks are refreshed.
- [Native date-input behavior varies by browser] → Verify keyboard save and clear
  flows in the supported browser rather than relying on pointer-only interaction.
- [API rejection could desynchronize the editor] → Commit returned values only
  after success and retain the prior value while announcing failures.

## Migration Plan

There is no persistent data migration. Implement the nullable date API contract
before enabling the editor, then add the controls and overdue rendering. Roll
back the Frontend by removing the editor and cue while leaving compatible task
date fields untouched.

## Role change scope

This change owns FE-REQ-002-date-editor (Frontend) for REQ-002. Its contract is
[specs/FE-REQ-002-date-editor/spec.md](specs/FE-REQ-002-date-editor/spec.md), and its checklist is
[tasks.md](tasks.md). Shared product decisions above are preserved. Other role
changes remain independent.
