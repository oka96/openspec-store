# Proposal

## Why

Tasks need a clear time commitment so users can see what needs attention today. A date-only field avoids ambiguity about time-of-day scheduling.

## What Changes

- Add an accessible date-only editor and explicit clear control to each task.
- Submit saved dates as YYYY-MM-DD strings and clears as explicit null values,
  while preserving the displayed date and announcing feedback when an update fails.
- Show a visible overdue text cue only when an incomplete task's due date is
  earlier than the viewer's local calendar date; keep due-today and completed
  task dates visible without an overdue cue.

## Capabilities

### New Capabilities

- `FE-REQ-002-date-editor`: Date editor and overdue cues.

### Modified Capabilities

None.

## Impact

Illustrative browser task editor and task-list rendering, plus integration with
the nullable date API contract and date-boundary acceptance coverage. This store
contains sample specification artifacts only; seeded checkboxes are not product
implementation or test evidence. No new services, dependencies, or authentication.

## Kanban

- Requirement title: Due dates & overdue cues
- Requirement summary: Give each task an optional due date and make overdue work visible.
- Spec title: Date editor and overdue cues
- Owner: Maya · sample
- Role note: Waiting for SA date-field sign-off.
- State: backlog
- Note: Waiting for SA date-field sign-off.
